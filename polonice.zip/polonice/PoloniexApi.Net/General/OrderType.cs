﻿namespace Jojatekok.PoloniexAPI
{
    /// <summary>Represents the type of an order.</summary>
    public enum OrderType
    {
        Buy,
        Sell
    }
}

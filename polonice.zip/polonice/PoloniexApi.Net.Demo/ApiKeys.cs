﻿namespace Jojatekok.PoloniexAPI.Demo
{
    struct ApiKeys
    {
        // WARNING: In order not to expose the changes of this file to git, please
        //          run the following command every time you clone the repository:
        // git update-index --assume-unchanged "PoloniexApi.Net.Demo\ApiKeys.cs"
        internal const string PublicKey = "";
        internal const string PrivateKey = "";
    }
}
